<p align="center">
<img src="https://telegra.ph/file/53fe8d162708b4a876c33.jpg" alt="Dracule Mihawk" width="500"/>


</p>
<p align="center">
<a href="#"><img title="Dracule Mihawk" src="https://img.shields.io/badge/Dracule%20Mihawk-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/NzrlAfndi/Dracule-Mihawk"><img title="AUTHOR" src="https://img.shields.io/badge/Author-Nzrl%20Afndi-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/NzrlAfndi/Dracule-Mihawk"><img title="Followers" src="https://img.shields.io/github/followers/NzrlAfndi?color=blue&style=flat-square"></a>
<a href="https://github.com/NzrlAfndi/Dracule-Mihawk"><img title="Stars" src="https://img.shields.io/github/stars/NzrlAfndi/Dracule-Mihawk?color=red&style=flat-square"></a>
<a href="https://github.com/NzrlAfndi/Dracule-Mihawk/network/members"><img title="Forks" src="https://img.shields.io/github/forks/NzrlAfndi/Dracule-Mihawk?color=red&style=flat-square"></a>
<a href="https://github.com/NzrlAfndi/Dracule-Mihawk/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/NzrlAfndi/Dracule-Mihawk?label=Watchers&color=blue&style=flat-square"></a>
</p>

---

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/NzrlAfndi/Dracule-Mihawk)

---

## For Your Info ☕
* This Is A WhatsApp Bot With Baileys From [`@adiwajshing/baileys-md`](https://github.com/adiwajshing/baileys/tree/multi-device) And Edited By [`Nzrl Afndi`](https://github.com/NzrlAfndi/Dracule-Mihawk) You Can Get The Edited Script In Channel [`NZRLAFNDI`](https://youtube.com/c/NZRLAFNDI)

## Connect With Me 🌱
* [`Instagram`](https://instagram.com/_nzrlafndi)
* [`Whatsapp`](https://wa.me/6281540022632?text=Assalamualaikum)
* [`Whatsapp Group`](https://chat.whatsapp.com/KXqad1SSAk64AmV8IHsoZZ)
* [`Youtube`](https://youtube.com/c/NzrlAfndi)
* [`Github`](https://github.com/NzrlAfndi)

## Support Me
* [`Saweria`](https://saweria.co/Fandyy)

Thanks For Donate

## Thanks To 🏆
* [`Adiwajshing`](https://github.com/adiwajshing)
* [`Nurutomo`](https://github.com/Nurutomo)
* [`Istikmal`](https://github.com/BochilGaming)
* [`Dika Ardnt.`](https://github.com/DikaArdnt)
* [`Nzrl Afndi`](https://github.com/NzrlAfndi)
* [`Ferdi Zaki`](https://github.com/FERDIZ-afk)
* [`Fatih Arridho`](https://github.com/FatihArridho)
* [`Erlan`](https://github.com/ERLANRAHMAT)
* [`Zhwzein`](https://github.com/Zhwzein)
* [`Penyedia Module`](https://npmjs.com)

## License
License: [MIT](https://en.wikipedia.org/wiki/MIT_License)

## UNTUK PENGGUNA WINDOWS/RDP

* Unduh & Instal Git [`Klik Disini`](https://git-scm.com/downloads)
* Unduh & Instal NodeJS [`Klik Disini`](https://nodejs.org/en/download)
* Unduh & Instal FFmpeg [`Klik Disini`](https://ffmpeg.org/download.html) (**Jangan Lupa Tambahkan FFmpeg ke variabel lingkungan PATH**)


```bash
git clone https://github.com/NzrlAfndi/Dracule-Mihawk
cd Dracule-Mihawk
npm install
```


## FOR HEROKU USER
- heroku/nodejs
- https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest.git
- https://github.com/clhuang/heroku-buildpack-webp-binaries.git


## FOR TERMUX/UBUNTU/SSH USER

```bash
apt update && apt upgrade
apt install git -y
apt install nodejs -y
apt install ffmpeg -y
apt install yarn
git clone https://github.com/NzrlAfndi/Dracule-Mihawk
cd Dracule-Mihawk
yarn
npm start
```

## Installing
```bash
$ node .
#standr run
$ npm run dev
#run with nodemon
```

## ❗ Warning
WhatsApp bot is still in the development stage, so there are a few bugs
WhatsApp Connection (BETA, not working perfectly)

Editing Number Owner And More On [`settings.js`](https://github.com/NzrlAfndi/Dracule-Mihawk/blob/master/settings.js)
